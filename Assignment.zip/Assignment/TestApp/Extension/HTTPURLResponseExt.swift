//
//  HTTPURLResponseExt.swift

import Foundation

// MARK: - HTTPURLResponse Extension to check the success response code
extension HTTPURLResponse {
    var hasSuccessStatusCode: Bool {
        return 200...299 ~= statusCode
    }
}
