//
//  LoadingExt.swift

import UIKit
//import NVActivityIndicatorView

//fileprivate let nvA = NVActivityIndicatorView(frame: CGRect(x: 50, y: 50, width: 30, height: 30))

extension UIViewController {
    
    func startActivityIndicator() {
        
        // Ensure the UI is updated from the main thread
        // in case this method is called from a closure
        
        
        DispatchQueue.main.async {
            
//            nvA.type = type
//            nvA.startAnimating()

            
            
//            // Create the activity indicator
//            let activityData = ActivityData(size: , type: type, color: .blue, backgroundColor: )
//            
//            
//            NVActivityIndicatorView.init(frame: <#T##CGRect#>)
//            
//            
//            NVActivityIndicatorView(frame: CGSize(width: 80, height: 80), type: type, color: .init(white: 0.4, alpha: 0.5), padding: padding)
//
//            
//            
//            // Start animating
//            NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData)
        }
    }
    
    func stopActivityIndicator() {
        
        // Again, we need to ensure the UI is updated from the main thread!
        DispatchQueue.main.async {
//            nvA.stopAnimating()
        }
    }
}
