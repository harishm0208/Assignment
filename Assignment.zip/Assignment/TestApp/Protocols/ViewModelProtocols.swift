//
//  ViewModelProtocols.swift


import Foundation

// MARK: - Resource View Model Delegate
protocol ResourcesViewModelDelegate: AnyObject {
    func onFetchCompleted()
    func onFetchFailed(with reason: String)
}

// MARK: - Categories View Model Delegate
protocol CategoriesViewModelDelegate: AnyObject {
    func onFetchCompleted()
    func onFetchFailed(with reason: String)
}
