//
//  ContactInfo.swift

import Foundation

// MARK: - Contact Info
struct ContactInfo: Codable {
    let website: [String]?
    let email: [String]?
    let phoneNumber: [String]?
    let faxNumber, tollFree: [String]?
}
