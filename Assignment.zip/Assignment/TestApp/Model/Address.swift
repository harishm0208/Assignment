//
//  Address.swift


import Foundation

// MARK: - Address
struct Address: Codable {
    let address1, label, zipCode, city: String?
    let state, country: String?
    let gps: Gps?
}
