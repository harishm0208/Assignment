//
//  SocialMedia.swift


import Foundation

// MARK: - Social Media
struct SocialMedia: Codable {
    let youtubeChannel, twitter, facebook: [String]?
}
