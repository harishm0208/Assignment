//
//  SortType.swift


import Foundation

// MARK: - Sort Type Enum
// A-Z, Z-A, unordered
enum SortType {
    case a2z
    case z2a
    case unordered
}
